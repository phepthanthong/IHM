﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class ListeNoeuds : Form
    {
        List<Noeud> listNoeud = new List<Noeud>();
        DessinObjets dess = new DessinObjets();

        public ListeNoeuds()
        {
            InitializeComponent();
        }
        
        public void Init(List<Noeud> noeuds, DessinObjets dessinObjets)
        {
            dess = dessinObjets;
            listeDesNoeuds.View = View.Details;
            listeDesNoeuds.Columns.Clear();
            listeDesNoeuds.Columns.Add("Epaisseur");
            listeDesNoeuds.Columns.Add("Couleur");
            listeDesNoeuds.Columns.Add("Position");
            this.listNoeud = noeuds;

            dess.drawnNodeEvent += dess_drawnNodeEvent;
            Refresh();            
        }        

        private void dess_drawnNodeEvent(object sender, DessinObjets.NodeDrawnArg e)
        {
            Noeud n = e.Noeud;

            // ajouter ce noeud dans la liste view
            ListViewItem it = new ListViewItem(n.Épaisseur.ToString());
            it.SubItems.Add(n.Couleur.ToString());
            it.SubItems.Add(n.Centre.ToString());
            listeDesNoeuds.Items.Add(it);

            Refresh();
        }     
    }
}
