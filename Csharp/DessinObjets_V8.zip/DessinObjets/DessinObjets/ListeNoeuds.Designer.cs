﻿namespace DessinObjets
{
    partial class ListeNoeuds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listeDesNoeuds = new System.Windows.Forms.ListView();
            this.Epaisseur = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Couleur = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Position = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // listeDesNoeuds
            // 
            this.listeDesNoeuds.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Epaisseur,
            this.Couleur,
            this.Position});
            this.listeDesNoeuds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listeDesNoeuds.Location = new System.Drawing.Point(0, 0);
            this.listeDesNoeuds.Name = "listeDesNoeuds";
            this.listeDesNoeuds.Size = new System.Drawing.Size(728, 449);
            this.listeDesNoeuds.TabIndex = 0;
            this.listeDesNoeuds.UseCompatibleStateImageBehavior = false;
            // 
            // ListeNoeuds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 449);
            this.Controls.Add(this.listeDesNoeuds);
            this.Name = "ListeNoeuds";
            this.Text = "ListeNoeuds";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listeDesNoeuds;
        private System.Windows.Forms.ColumnHeader Epaisseur;
        private System.Windows.Forms.ColumnHeader Couleur;
        private System.Windows.Forms.ColumnHeader Position;
    }
}