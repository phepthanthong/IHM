﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class DessinObjets : Form
    {
        List<Noeud> noeuds = new List<Noeud>();
        List<Trait> traits = new List<Trait>();
        Noeud noeudCourant = null;
        Point pointCourant = Point.Empty;
        bool enDéplacement;
        bool dessinTrait;
        public DessinObjets()
        {
            InitializeComponent();
        }

        private void DessinObjets_MouseDown(object sender, MouseEventArgs e)
        {
            noeudCourant = NoeudCourant(e);
            if (déplacement.Checked)
            {
                if (noeudCourant != null)
                {
                    enDéplacement = true;
                }
            }
            else
            {
                if (noeudCourant == null)
                {
                    Noeud noeud = new Noeud(e.Location, new Size(10, 15), Color.Black, 2);
                    noeuds.Add(noeud);
                }
                else dessinTrait = true;
            }
            Refresh();
        }

        private Noeud NoeudCourant(MouseEventArgs e)
        {
            foreach (Noeud re in noeuds)
            {
                if (re.Contains(e.Location))
                {
                    return re;
                }
            }
            return null;
        }

        private void DessinObjets_Paint(object sender, PaintEventArgs e)
        {
            foreach (Noeud n in noeuds)
                n.Dessine(e.Graphics);
            foreach (Trait t in traits)
                t.Dessine(e.Graphics);
            if (pointCourant != Point.Empty)
            {
                Noeud fin = new Noeud(pointCourant, new Size(10, 15), Color.Black, 2);
                fin.Dessine(e.Graphics);
                e.Graphics.DrawLine(Pens.Red, noeudCourant.Centre, pointCourant);
            }
        }

        private void DessinObjets_MouseUp(object sender, MouseEventArgs e)
        {
                enDéplacement = false;
                if (dessinTrait)
                {
                    Noeud fin = NoeudCourant(e);
                    if (fin == null)
                    {
                        fin = new Noeud(e.Location, new Size(10, 15), Color.Black, 2);
                        noeuds.Add(fin);
                    }
                    Trait t = new Trait(noeudCourant, fin, Color.Black, 1);
                    traits.Add(t);
                    Refresh();
                    dessinTrait = false;
                }
                noeudCourant = null;
                pointCourant = Point.Empty;
        }
        
        private void DessinObjets_MouseMove(object sender, MouseEventArgs e)
        {
            // si noeud en deplacement, deplacer le noeud
            if (enDéplacement)
            {
                if (noeudCourant != null)
                {
                    noeudCourant.Move(e.Location);
                }
            }
            if (dessinTrait)
                pointCourant = e.Location;
            Refresh();
        }

        private Noeud TrouveNoeud(Point p)
        {
            foreach (Noeud re in noeuds)
            {
                if (re.Contains(p))
                {
                    return re;
                }
            }
            return null;
        }
        
    }
}
    


