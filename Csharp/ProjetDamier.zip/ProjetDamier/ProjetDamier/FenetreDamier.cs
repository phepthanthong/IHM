﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetDamier
{
    public partial class FenetreDamier : Form
    {
        #region attributs
        Rectangle rectangle;
        Rectangle cercle;
        List<Case> damier = new List<Case>();
        Case damierCourant = null;
        #endregion attributs
        public FenetreDamier()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            rectangle = new Rectangle(50, 50, 100, 100);
            cercle = new Rectangle(50, 50, 100, 100);
        }

        private void FenetreDamier_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawRectangle(Pens.Black, rectangle);
            e.Graphics.FillRectangle(Brushes.Black, rectangle);
            e.Graphics.DrawRectangle(Pens.Black, cercle);
            e.Graphics.FillEllipse(Brushes.White, cercle);
        }

        private void FenetreDamier_MouseDown(object sender, MouseEventArgs e)
        {
            
                Case cases = new Case(e.Location,rectangle,cercle);
                damier.Add(cases);
        }

        /*public Case DamierCourant(MouseEventArgs e)
        {
            foreach (Case ca in damier)
            {
                if (ca.Contains(e.Location))
                    return ca;
            }
            return null;
        }*/        

        public void Dessine(Graphics g)
        {
            Pen p = new Pen(Brushes.Black);
            g.DrawRectangle(p, rectangle);
        }
        
    }
}
