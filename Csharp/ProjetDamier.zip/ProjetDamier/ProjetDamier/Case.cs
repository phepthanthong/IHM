﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ProjetDamier
{
    class Case
    {
        #region atributs
        private Rectangle rect;
        private Rectangle pion;
        private Color couleurFond;
        private Point point;
        #endregion attributs

        private void Init()
        {
            rect = new Rectangle(200,200,100,100);
            pion = new Rectangle(200, 200, 100, 100);
        }

        public Case(Rectangle r, Rectangle cer, Color c)
        {
            rect = r;
            pion = cer;
            couleurFond = c;
        }

        public Case(Point point, Rectangle r, Rectangle cer)
        {
            this.point = point;
            this.rect = r;
            this.pion = cer;
        }

        public bool Contains(Point p)
        {
            return rect.Contains(p);
        }
                
    }
}
