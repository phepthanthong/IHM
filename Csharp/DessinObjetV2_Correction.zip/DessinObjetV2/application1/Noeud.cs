﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace application1
{
    public class Noeud
    {
        private Rectangle rect;
        private Color couleur;
        private int épaisseur;

        public Point Centre
        {
            get { return new Point(rect.Location.X + rect.Width / 2, rect.Location.Y + rect.Height / 2); }
            set
            {
                rect.Location = new Point(value.X - rect.Width / 2, value.Y - rect.Height / 2);
            }
        }

        public Noeud(Rectangle r, Color c, int e)
        {
            rect = r;
            couleur = c;
            épaisseur = e;
        }
        public Noeud(Point p, Size s, Color c, int e)
        {
            rect = new Rectangle(p, s);
            couleur = c;
            épaisseur = e;
        }
        public void Dessine(Graphics g)
        {
            Pen p = new Pen(couleur, épaisseur);
            g.DrawRectangle(p, rect);
        }

        public bool Contains(Point point)
        {
            return rect.Contains(point);
        }

        public void Move(Point point)
        {
            Centre=point;
        }
    }
}
