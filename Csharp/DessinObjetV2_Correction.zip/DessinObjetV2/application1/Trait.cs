﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace application1
{
    public class Trait
    {
        private Noeud source;
        private Noeud destination;
        private Color couleur;
        private int epaisseur;
        
        public Trait(Noeud sour, Noeud dest, Color c, int e)
        {
            source = sour;
            destination = dest;
            couleur = c;
            epaisseur = e;
        }
        public void Dessine(Graphics g)
        {
            Pen p = new Pen(couleur, epaisseur);
            g.DrawLine(p, source.Centre, destination.Centre);
        }
    }

}
