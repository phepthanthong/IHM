﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace application1
{
    public partial class Dessin : Form
    {
        private List<Noeud> noeuds = new List<Noeud>();
        private List<Trait> traits = new List<Trait>();

        private Color couleurParDéfaut = Color.Black;
        private int epaisseurParDéfaut = 1;

        private Noeud noeudCourant;
        private bool noeudEnDeplacement = false;
        private bool traitEnCoursCréation = false;
        private Point extremiteTrait;

        public Dessin()
        {
            InitializeComponent();
        }

        private void Dessin_Paint(object sender, PaintEventArgs e)
        {
            foreach (Noeud n in noeuds)
                n.Dessine(e.Graphics);
            foreach (Trait t in traits)
                t.Dessine(e.Graphics);
            if (traitEnCoursCréation)
                e.Graphics.DrawLine( new Pen(couleurParDéfaut, epaisseurParDéfaut),noeudCourant.Centre,extremiteTrait);
        }

        private void Dessin_MouseDown(object sender, MouseEventArgs e)
        {
            noeudCourant  = ChercheNoeud(e.Location);
            if (deplacement.Checked)
            {
                //Déplacement
                if (noeudCourant != null)
                // deplacement du noeud selectionné
                {
                    noeudEnDeplacement = true;
                }
            }
            else
            {
                //Dessin
                if (noeudCourant == null)
                {
                    Noeud noeud = new Noeud(new Rectangle(e.Location, new Size(10, 10)),
                      couleurParDéfaut, epaisseurParDéfaut);
                    noeuds.Add(noeud);
                }
                else
                {
                    traitEnCoursCréation = true;
                    extremiteTrait = e.Location;
                }
            }
            Refresh();
        }

        private Noeud ChercheNoeud( Point p)
        {
            foreach (Noeud re in noeuds)
                if (re.Contains(p)) 
                    return re;
            return null;
        }

        private void Dessin_MouseMove(object sender, MouseEventArgs e)
        {
            if (noeudEnDeplacement)
            {
                noeudCourant.Move(e.Location);
                Refresh();
            }
            if (traitEnCoursCréation)
            {
                extremiteTrait = e.Location;
                Refresh();
            }
        }

        private void Dessin_MouseUp(object sender, MouseEventArgs e)
        {
            if (noeudEnDeplacement)
            {
                noeudCourant.Move(e.Location);
                noeudEnDeplacement = false;
                Refresh();
            }
            if (traitEnCoursCréation)
            {
                traitEnCoursCréation = false;
                Noeud fin = ChercheNoeud(e.Location);
                if (fin != null)
                {
                    Trait t = new Trait(noeudCourant, fin, Color.Black, 1);
                    traits.Add(t);                 
                }
                Refresh();
            }
        }
    }
}
