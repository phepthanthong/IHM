﻿namespace DessinObjets
{
    partial class DessinObjets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DessinObjets));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.déplacement = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonCouleur = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.déplacement,
            this.toolStripButtonCouleur});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(577, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // déplacement
            // 
            this.déplacement.CheckOnClick = true;
            this.déplacement.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.déplacement.Image = ((System.Drawing.Image)(resources.GetObject("déplacement.Image")));
            this.déplacement.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.déplacement.Name = "déplacement";
            this.déplacement.Size = new System.Drawing.Size(23, 22);
            this.déplacement.Text = "deplacement";
            // 
            // toolStripButtonCouleur
            // 
            this.toolStripButtonCouleur.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonCouleur.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCouleur.Image")));
            this.toolStripButtonCouleur.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCouleur.Name = "toolStripButtonCouleur";
            this.toolStripButtonCouleur.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonCouleur.Text = "toolStripButtonCouleur";
            this.toolStripButtonCouleur.Click += new System.EventHandler(this.toolStripButtonCouleur_Click);
            // 
            // DessinObjets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(577, 329);
            this.Controls.Add(this.toolStrip1);
            this.DoubleBuffered = true;
            this.Name = "DessinObjets";
            this.Text = "DessinNoeud";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.DessinObjets_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DessinObjets_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DessinObjets_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.DessinObjets_MouseUp);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton déplacement;
        private System.Windows.Forms.ToolStripButton toolStripButtonCouleur;

    }
}

