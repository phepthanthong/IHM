﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class Parametres : Form
    {
        public Color Couleur
        {
            get { return labelCouleur.BackColor; }
            set { }
        }
        public Parametres()
        {
            InitializeComponent();
        }

        private void labelCouleur_Click(object sender, EventArgs e)
        {
            ColorDialog d = new ColorDialog();
            d.Color = labelCouleur.BackColor;
            if (d.ShowDialog() == DialogResult.OK)
            {
                labelCouleur.BackColor = d.Color;
            }

        }
    }
}
