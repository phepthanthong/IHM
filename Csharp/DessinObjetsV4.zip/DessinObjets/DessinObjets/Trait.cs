﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DessinObjets
{
    public class Trait
    {
        #region attributs
        private Noeud source;
        private Noeud destination;
        private Color couleur;
        private int epaisseur;
        #endregion attributs
        public Trait(Noeud sour, Noeud dest, Color c, int e)
        {
            source = sour;
            destination = dest;
            couleur = c;
            epaisseur = e;
        }
        public void Dessine(Graphics g)
        {
            Pen p = new Pen(couleur, epaisseur);
            g.DrawLine(p, source.Centre, destination.Centre);
        }
    }
}
