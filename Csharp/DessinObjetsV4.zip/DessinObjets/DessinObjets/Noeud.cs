﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DessinObjets
{
    public class Noeud
    {
        #region attributs
            private Rectangle rect;
            private Color couleur;
            private int épaisseur;
        #endregion attributs
        #region propriete
            public int Épaisseur
        {
            get { return épaisseur; }
            set { épaisseur = value; }
        }
            public Point Centre
            {
                get { return new Point(rect.X + rect.Width / 2, rect.Y + rect.Height / 2); }
                set
                    {
                        rect.X = value.X - rect.Width / 2;
                        rect.Y = value.Y - rect.Height / 2;
                    }
            }
        #endregion propriete
        public Noeud(Rectangle r, Color c, int e)
        {
            rect = r;
            couleur = c;
            épaisseur = e;
        }
        public Noeud(Point p, Size s, Color c, int e)
        {
            rect = new Rectangle(new Point(p.X - s.Width / 2, p.Y - s.Height /2), s);
            couleur = c;
            épaisseur = e;
        }
        public void Dessine(Graphics g)
        {
            Pen p = new Pen(couleur, épaisseur);
            g.DrawRectangle(p, rect);
        }
        public bool Contains(Point p)
        {   
            /*if (rect.Contains(p))
            //if (p.X >= rect.X && p.X <= rect.X + rect.Width && p.Y >= rect.Y && p.Y <= rect.Height)
                return true;
            else return false; */
            return rect.Contains(p);
        }
        public void Move(Point p)
        {
            rect.Location = new Point(p.X - rect.Width / 2, p.Y - rect.Height /2);
        }
        
        
    }
}
