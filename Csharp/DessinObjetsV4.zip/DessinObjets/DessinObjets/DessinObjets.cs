﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class DessinObjets : Form
    {
        #region attributs
        List<Noeud> noeuds = new List<Noeud>();
        List<Trait> traits = new List<Trait>();
        Noeud noeudCourant = null;
        Point pointCourant = Point.Empty;
        bool enDéplacement;
        bool dessinTrait;

        Color couleurParDéfaut = Color.Black;
        int epaisseurParDéfaut = 1;
        Size tailleParDéfaut = new Size(10, 15);
        #endregion attributs

        public DessinObjets()
        {
            InitializeComponent();
            //moinsToolStripMenuItem.Enabled = false;
        }

        private void DessinObjets_MouseDown(object sender, MouseEventArgs e)
        {
            noeudCourant = NoeudCourant(e);
            switch (e.Button)
            {
                case System.Windows.Forms.MouseButtons.Left:
                    {
                        if (déplacement.Checked)
                        {
                            if (noeudCourant != null)
                            {
                                enDéplacement = true;
                            }
                        }
                        else
                        {
                            if (noeudCourant == null)
                            {
                                Noeud noeud = new Noeud(e.Location, new Size(10, 15), couleurParDéfaut, epaisseurParDéfaut);
                                noeuds.Add(noeud);
                            }
                            else dessinTrait = true;
                        }
                        break;
                    }
                case System.Windows.Forms.MouseButtons.Right:
                    {
                        if (noeudCourant != null)
                        {
                            Parametres d = new Parametres();
                            d.BackColor = Label.DefaultBackColor;
                            if (d.ShowDialog() == DialogResult.OK)
                            {
                                d.BackColor = Label.DefaultBackColor;
                            }
                        }
                        break;
                    }
            }
            Refresh();
        }
 
        private Noeud NoeudCourant(MouseEventArgs e)
        {
            foreach (Noeud re in noeuds)
            {
                if (re.Contains(e.Location))
                {
                    return re;
                }
            }
            return null;
        }

        private void DessinObjets_Paint(object sender, PaintEventArgs e)
        {
            foreach (Noeud n in noeuds)
                n.Dessine(e.Graphics);
            foreach (Trait t in traits)
                t.Dessine(e.Graphics);
            if (pointCourant != Point.Empty)
            {
                Noeud fin = new Noeud(pointCourant, tailleParDéfaut, couleurParDéfaut, epaisseurParDéfaut);
                fin.Dessine(e.Graphics);
                e.Graphics.DrawLine(Pens.Red, noeudCourant.Centre, pointCourant);
            }
        }

        private void DessinObjets_MouseUp(object sender, MouseEventArgs e)
        {
                enDéplacement = false;
                if (dessinTrait)
                {
                    Noeud fin = NoeudCourant(e);
                    if (fin == null)
                    {
                        fin = new Noeud(e.Location, new Size(10, 15), Color.Black, 2);
                        noeuds.Add(fin);
                    }
                    Trait t = new Trait(noeudCourant, fin, couleurParDéfaut, 1);
                    traits.Add(t);
                    Refresh();
                    dessinTrait = false;
                }
                noeudCourant = null;
                pointCourant = Point.Empty;
        }
        
        private void DessinObjets_MouseMove(object sender, MouseEventArgs e)
        {
            // si noeud en deplacement, deplacer le noeud
            if (enDéplacement)
            {
                if (noeudCourant != null)
                {
                    noeudCourant.Move(e.Location);
                }
            }
            if (dessinTrait)
                pointCourant = e.Location;
            Refresh();
        }

        private Noeud TrouveNoeud(Point p)
        {
            foreach (Noeud re in noeuds)
            {
                if (re.Contains(p))
                {
                    return re;
                }
            }
            return null;
        }

        private Noeud NoeudParDéfaut(Point point)
        {
            return new Noeud(point, tailleParDéfaut, couleurParDéfaut, epaisseurParDéfaut);
        }
        /*
        private void rougeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            couleurParDéfaut = Color.Red;    
        }

        private void plusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (epaisseurParDéfaut < 10)
            {
                epaisseurParDéfaut++;
                moinsToolStripMenuItem.Enabled = true;
            }
            if (epaisseurParDéfaut == 10) plusToolStripMenuItem.Enabled = false;
        }

        private void moinsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (epaisseurParDéfaut > 1)
            {
                epaisseurParDéfaut--;
                plusToolStripMenuItem.Enabled = true;
            }
            if (epaisseurParDéfaut == 1) moinsToolStripMenuItem.Enabled = false;
        }
        */
        private void toolStripButtonCouleur_Click(object sender, EventArgs e)
        {
            ColorDialog d = new ColorDialog();
            d.Color = couleurParDéfaut;
            if (d.ShowDialog() == DialogResult.OK) 
                couleurParDéfaut = d.Color;
        } 
        
    }
}
    


